package com.sighs.apricityui.layout;

import com.sighs.apricityui.style.*;

import com.sighs.apricityui.init.Element;
import com.sighs.apricityui.style.Style;

import java.util.ArrayList;
import java.util.List;
import com.sighs.apricityui.parser.CSS;

public final class Layout {
    private Layout() {
    }

    /**
     * 按顶层空白切分 CSS 值，函数体（calc()/min() 等）内的空白不切分。
     * 包内各布局器的 paren-aware 分词统一走这里（Box/Grid 原各自实现了一份）。
     * 输入是样式表里的稳定字符串，布局阶段逐帧重复切分（JFR 归因约 42MB），缓存之。
     * 返回不可变列表，调用方不得修改。
     */
    public static List<String> splitTopLevelWhitespace(String value) {
        if (value == null || value.isBlank()) return List.of();
        List<String> cached = SPLIT_CACHE.get(value);
        if (cached != null) return cached;
        List<String> parts = splitTopLevelWhitespaceUncached(value);
        SPLIT_CACHE.put(value, parts);
        return parts;
    }
    private static final int SPLIT_CACHE_LIMIT = 1024;
    private static final java.util.Map<String, List<String>> SPLIT_CACHE =
            java.util.Collections.synchronizedMap(new java.util.LinkedHashMap<>(128, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(java.util.Map.Entry<String, List<String>> eldest) {
                    return size() > SPLIT_CACHE_LIMIT;
                }
            });

    private static List<String> splitTopLevelWhitespaceUncached(String value) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        int start = -1;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == '(') depth++;
            else if (c == ')' && depth > 0) depth--;
            if (Character.isWhitespace(c) && depth == 0) {
                if (start >= 0) {
                    parts.add(value.substring(start, i));
                    start = -1;
                }
            } else if (start < 0) {
                start = i;
            }
        }
        if (start >= 0) parts.add(value.substring(start));
        return List.copyOf(parts);
    }

    public static Position computeChildPosition(Element element, Element parent, List<Element> siblings) {
        if (parent == null) return Position.ZERO;
        Style parentStyle = parent.getComputedStyle();
        if (parentStyle.isGridDisplay()) {
            return Grid.computeChildPosition(element, parent, siblings);
        }
        if (parentStyle.isFlexDisplay()) {
            return Flex.computeChildPosition(element, parent, siblings);
        }
        return NormalFlow.computeChildPosition(element, parent, siblings);
    }

    public static Size computeContentSize(Element element) {
        if (element == null) return Size.ZERO;
        Style style = element.getComputedStyle();
        if (style.isGridDisplay()) {
            return Grid.computeContentSize(element);
        }
        if (style.isFlexDisplay()) {
            return Flex.computeContentSize(element);
        }
        return NormalFlow.computeContentSize(element);
    }

    public static boolean isFlexDisplay(String display) {
        if (display == null) return false;
        String value = display.trim().toLowerCase();
        return "flex".equals(value) || "inline-flex".equals(value);
    }

    public static boolean isGridDisplay(String display) {
        if (display == null) return false;
        String value = display.trim().toLowerCase();
        return "grid".equals(value) || "inline-grid".equals(value);
    }

    /** 委托 {@link Style#isInFlow()}；保持 null 安全以兼容旧调用方。 */
    public static boolean isInFlow(Style style) {
        if (style == null) return false;
        return style.isInFlow();
    }
}
