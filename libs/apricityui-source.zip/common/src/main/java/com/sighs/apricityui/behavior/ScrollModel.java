package com.sighs.apricityui.behavior;

import com.mojang.blaze3d.vertex.PoseStack;
import com.sighs.apricityui.element.AbstractText;
import com.sighs.apricityui.event.MouseEvent;
import com.sighs.apricityui.render.Base;
import com.sighs.apricityui.render.Graph;
import com.sighs.apricityui.render.PoseMatrices;
import com.sighs.apricityui.render.Rect;
import com.sighs.apricityui.layout.Box;
import com.sighs.apricityui.style.Interaction;
import com.sighs.apricityui.layout.Position;
import com.sighs.apricityui.layout.Size;
import com.sighs.apricityui.style.Style;
import com.sighs.apricityui.render.Drawer;
import com.sighs.apricityui.init.Element;
import com.sighs.apricityui.parser.CSS;
import com.sighs.apricityui.parser.Selector.PseudoElement;

public final class ScrollModel {
    private static final double SCROLL_EASING_FACTOR = 0.2;
    private static final double SCROLL_OVERSCROLL_DAMPING = 0.4;
    private static final double SCROLL_STOP_EPSILON = 0.01;
    private static final double BASE_FRAME_MS = 16.6666666667;
    private static final double MAX_FRAME_MS = 50.0;
    /** Scrollbar dimensions are expressed in device pixels, then converted to document pixels. */
    private static final double SCROLLBAR_GUTTER = 8.0;
    private static final double SCROLLBAR_EPSILON = 0.5;
    private static final double SCROLLBAR_TRACK_SIZE = 6.0;
    private static final double SCROLLBAR_TRACK_INSET = 1.0;
    private static final double SCROLLBAR_MIN_THUMB_LENGTH = 10.0;
    private static final float SCROLLBAR_THUMB_DEPTH_FRACTION = 0.5f;
    /** 默认轨道/滑块颜色（ARGB）。与旧的硬编码值保持一致。 */
    private static final int SCROLLBAR_DEFAULT_TRACK_COLOR = 0x18B96A91;
    private static final int SCROLLBAR_DEFAULT_THUMB_COLOR = 0xB39F9F9F;
    /** scrollbar-width: thin 时的 CSS 像素宽度。 */
    private static final double SCROLLBAR_THIN_SIZE = 6.0;
    /** scrollbar-width: none / ::-webkit-scrollbar { display: none } 的隐藏开关。 */
    private static final double SCROLLBAR_HIDDEN = 0.0;

    private final Element owner;
    private long lastRenderStepNs;
    private boolean verticalScrollbarVisible;
    private boolean horizontalScrollbarVisible;
    private boolean scrollbarLayoutDirty;
    private DragAxis dragAxis = DragAxis.NONE;
    private double dragPointerOffset;
    private boolean scrollbarPointerActive;
    private double lastRenderStepDeltaLeft;
    private double lastRenderStepDeltaTop;
    /** 上一帧指针是否停在滑块上，用于驱动 ::-webkit-scrollbar-thumb:hover 重绘。 */
    private boolean lastThumbHovered;

    public ScrollModel(Element owner) {
        this.owner = owner;
    }

    public void setScrollLeft(double value) {
        owner.targetScrollLeft = applyOverscroll(value, getHorizontalScrollLimit());
    }

    public void setScrollTop(double value) {
        owner.targetScrollTop = applyOverscroll(value, getVerticalScrollLimit());
    }

    public double getScrollLeft() {
        return owner.scrollLeft;
    }

    public double getScrollTop() {
        return owner.scrollTop;
    }

    public double getTargetScrollLeft() {
        return owner.targetScrollLeft;
    }

    public double getTargetScrollTop() {
        return owner.targetScrollTop;
    }

    public boolean canScroll() {
        return canScrollVertically() || canScrollHorizontally();
    }

    public boolean canScrollVertically() {
        if (isViewportScroller()) {
            return allowsViewportUserScroll(resolveViewportOverflowY());
        }
        return Interaction.allowsUserScrollY(owner.getComputedStyle());
    }

    public boolean canScrollHorizontally() {
        if (isViewportScroller()) {
            return allowsViewportUserScroll(resolveViewportOverflowX());
        }
        return Interaction.allowsUserScrollX(owner.getComputedStyle());
    }

    public boolean hasVerticalScrollRange() {
        if (isViewportScroller() ? !canScrollVertically()
                : !Interaction.allowsUserScrollY(owner.getComputedStyle())) return false;
        commitLayoutMetrics();
        return getVerticalScrollLimitFromMetrics() > 0.5;
    }

    public boolean hasHorizontalScrollRange() {
        if (isViewportScroller() ? !canScrollHorizontally()
                : !Interaction.allowsUserScrollX(owner.getComputedStyle())) return false;
        commitLayoutMetrics();
        return getHorizontalScrollLimitFromMetrics() > 0.5;
    }

    public boolean tick() {
        if (!scrollbarLayoutDirty) return false;
        syncLayoutAfterMetricsCommit();
        return true;
    }

    public boolean stepRender() {
        if (!needsRenderStep()) {
            lastRenderStepNs = 0L;
            lastRenderStepDeltaLeft = 0;
            lastRenderStepDeltaTop = 0;
            return false;
        }

        double previousLeft = owner.scrollLeft;
        double previousTop = owner.scrollTop;
        double frameScale = consumeFrameScale();
        stepHorizontalScroll(frameScale);
        stepVerticalScroll(frameScale);
        lastRenderStepDeltaLeft = owner.scrollLeft - previousLeft;
        lastRenderStepDeltaTop = owner.scrollTop - previousTop;
        return Double.compare(previousLeft, owner.scrollLeft) != 0
                || Double.compare(previousTop, owner.scrollTop) != 0;
    }

    /** 最近一次 {@link #stepRender()} 产生的 scrollLeft 位移；供滚动平移快速路径使用。 */
    public double getLastRenderStepDeltaLeft() {
        return lastRenderStepDeltaLeft;
    }

    /** 最近一次 {@link #stepRender()} 产生的 scrollTop 位移；供滚动平移快速路径使用。 */
    public double getLastRenderStepDeltaTop() {
        return lastRenderStepDeltaTop;
    }

    public boolean needsRenderStep() {
        return !isScrollSettled(owner.scrollLeft, owner.targetScrollLeft)
                || !isScrollSettled(owner.scrollTop, owner.targetScrollTop);
    }

    /**
     * Whether the render list should reserve a scrollbar paint node.  The
     * actual overflow metrics are refreshed by drawScrollbar(), so this check
     * intentionally also returns true for auto/scroll overflow declarations.
     */
    public boolean mayRenderScrollbar() {
        if (isScrollbarHidden()) return false;
        return verticalScrollbarVisible
                || horizontalScrollbarVisible
                || hasStableScrollbarGutter()
                || mayShowVerticalScrollbar()
                || mayShowHorizontalScrollbar();
    }

    public boolean handleMouseDown(MouseEvent event) {
        if (event == null || event.button != 0) return false;
        if (!mayRenderScrollbar()) return false;

        Rect rect = Rect.of(owner);
        AxisGeometry vertical = axisGeometry(true, rect);
        AxisGeometry horizontal = axisGeometry(false, rect);
        AxisGeometry hit = contains(vertical, event.clientX, event.clientY)
                ? vertical
                : contains(horizontal, event.clientX, event.clientY) ? horizontal : null;
        if (hit == null) return false;

        scrollbarPointerActive = true;
        double beforeLeft = owner.getTargetScrollLeft();
        double beforeTop = owner.getTargetScrollTop();
        double pointer = hit.vertical ? event.clientY : event.clientX;
        if (pointer >= hit.thumbStart() && pointer <= hit.thumbEnd()) {
            dragAxis = hit.vertical ? DragAxis.VERTICAL : DragAxis.HORIZONTAL;
            dragPointerOffset = pointer - hit.thumbStart();
        } else {
            double page = hit.vertical ? getScrollportHeight() : getScrollportWidth();
            double direction = pointer < hit.thumbStart() ? -1.0 : 1.0;
            if (hit.vertical) {
                setScrollTop(clampScrollTarget(owner.getTargetScrollTop() + direction * page,
                        getVerticalScrollLimitFromMetrics()));
            } else {
                setScrollLeft(clampScrollTarget(owner.getTargetScrollLeft() + direction * page,
                        getHorizontalScrollLimitFromMetrics()));
            }
            owner.dispatchScrollEventIfChanged(beforeLeft, beforeTop);
        }
        return true;
    }

    public boolean handleMouseMove(MouseEvent event) {
        if (event == null || !scrollbarPointerActive) return false;
        if (dragAxis == DragAxis.NONE) return true;
        AxisGeometry geometry = axisGeometry(dragAxis == DragAxis.VERTICAL, Rect.of(owner));
        if (geometry == null) return true;

        double pointer = geometry.vertical ? event.clientY : event.clientX;
        double travel = geometry.trackLength() - geometry.thumbLength();
        double ratio = travel <= 0 ? 0 : (pointer - geometry.trackStart() - dragPointerOffset) / travel;
        ratio = Math.max(0, Math.min(1, ratio));
        double limit = geometry.vertical ? getVerticalScrollLimitFromMetrics() : getHorizontalScrollLimitFromMetrics();
        setScrollImmediate(geometry.vertical, ratio * limit);
        return true;
    }

    public boolean handleMouseUp(MouseEvent event) {
        if (!scrollbarPointerActive) return false;
        scrollbarPointerActive = false;
        dragAxis = DragAxis.NONE;
        dragPointerOffset = 0;
        return true;
    }

    public boolean isScrollbarInteractionActive() {
        return scrollbarPointerActive;
    }

    public void drawScrollbar(PoseStack poseStack, Rect rectRenderer) {
        if (isScrollbarHidden()) {
            setScrollbarVisibility(false, false);
            return;
        }
        if (!mayShowHorizontalScrollbar() && !mayShowVerticalScrollbar()) {
            setScrollbarVisibility(false, false);
            return;
        }
        if (!verticalScrollbarVisible && !horizontalScrollbarVisible && !hasStableScrollbarGutter()) return;

        trackThumbHoverRepaint();
        Position bodyPos = rectRenderer.getBodyRectPosition();
        Size bodySize = rectRenderer.getBodyRectSize();
        if (verticalScrollbarVisible) drawVerticalScrollbar(poseStack, bodyPos, bodySize);
        if (horizontalScrollbarVisible) drawHorizontalScrollbar(poseStack, bodyPos, bodySize);
    }

    public double getVerticalScrollbarGutter() {
        return scrollbarReservesGutter(verticalScrollbarVisible) ? scrollbarGutter() : 0;
    }

    public double getHorizontalScrollbarGutter() {
        return scrollbarReservesGutter(horizontalScrollbarVisible) ? scrollbarGutter() : 0;
    }

    /** 隐藏时既不绘制也不预留空间。 */
    private boolean scrollbarReservesGutter(boolean axisVisible) {
        if (isScrollbarHidden()) return false;
        return axisVisible || hasStableScrollbarGutter();
    }

    public boolean hasStableScrollbarGutter() {
        return com.sighs.apricityui.style.Interaction.hasStableScrollbarGutter(
                owner.getComputedStyle().scrollbarGutter);
    }

    // ------------------------------------------------------------------
    // CSS 接入：scrollbar-width / scrollbar-color / ::-webkit-scrollbar*
    // ------------------------------------------------------------------

    /** {@code scrollbar-width: none} 或 {@code ::-webkit-scrollbar { display: none }}。 */
    public boolean isScrollbarHidden() {
        if (com.sighs.apricityui.style.Interaction.isScrollbarHidden(owner.getComputedStyle().scrollbarWidth)) {
            return true;
        }
        return "none".equalsIgnoreCase(pseudoValue(PseudoElement.SCROLLBAR, "display", null));
    }

    /** 读取滚动条伪元素上某个声明的原始值；未声明返回 fallback。 */
    private String pseudoValue(PseudoElement kind, String property, String fallback) {
        if (kind == null || property == null) return fallback;
        java.util.HashMap<String, com.sighs.apricityui.parser.CSS.Declaration> styles =
                owner.getScrollbarPseudoStyles(kind);
        if (styles == null || styles.isEmpty()) return fallback;
        com.sighs.apricityui.parser.CSS.Declaration declaration = styles.get(property);
        if (declaration == null || declaration.value() == null || declaration.value().isBlank()) return fallback;
        return declaration.value().trim();
    }

    /**
     * 滚轴粗细（文档像素）：{@code ::-webkit-scrollbar { width }} 优先，其次
     * {@code scrollbar-width: thin|<length>}；两者都没有时用 6dp 默认值。
     */
    private double scrollbarTrackSize() {
        Double explicitSize = explicitScrollbarSize();
        return explicitSize == null ? devicePixelsToDocumentPixels(SCROLLBAR_TRACK_SIZE) : explicitSize;
    }

    /**
     * CSS 显式声明的滚动条粗细；未声明返回 {@code null}（调用方回退默认值）。
     * 返回值是文档像素：CSS 长度直接用，DP 默认值才做缩放换算。
     */
    private Double explicitScrollbarSize() {
        Double fromPseudo = parseCssLength(pseudoValue(PseudoElement.SCROLLBAR, "width", null));
        if (fromPseudo != null) return Math.max(0d, fromPseudo);

        String normalized = com.sighs.apricityui.style.Interaction.normalizeScrollbarWidth(
                owner.getComputedStyle().scrollbarWidth);
        if ("none".equals(normalized)) return null;
        if ("thin".equals(normalized)) return devicePixelsToDocumentPixels(SCROLLBAR_THIN_SIZE);
        Double length = parseCssLength(normalized);
        return length == null ? null : Math.max(0d, length);
    }

    /** 轨道与滚动条边界之间的内缩，跟随粗细等比缩放。 */
    private double scrollbarTrackInset() {
        double size = scrollbarTrackSize();
        if (size <= 0d) return 0d;
        return size * (SCROLLBAR_TRACK_INSET / SCROLLBAR_TRACK_SIZE);
    }

    /**
     * gutter 是滚动条占用的可交互/预留宽度。有 CSS 粗细声明时以它为准
     * （再加两侧 inset），否则沿用 8dp 默认值，保证既有布局不变。
     */
    private double scrollbarGutter() {
        return explicitScrollbarSize() == null
                ? devicePixelsToDocumentPixels(SCROLLBAR_GUTTER)
                : scrollbarTrackSize() + scrollbarTrackInset() * 2d;
    }

    private double scrollbarMinThumbLength() {
        return devicePixelsToDocumentPixels(SCROLLBAR_MIN_THUMB_LENGTH);
    }

    /** 解析 {@code <length>}（当前支持 px）；非长度返回 null。 */
    private static Double parseCssLength(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String value = raw.trim().toLowerCase(java.util.Locale.ROOT);
        if (!value.endsWith("px")) return null;
        try {
            double parsed = Double.parseDouble(value.substring(0, value.length() - 2).trim());
            return Double.isFinite(parsed) ? parsed : null;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private boolean stepHorizontalScroll(double frameScale) {
        ScrollStep step = stepScrollAxis(owner.scrollLeft, owner.targetScrollLeft, getHorizontalScrollLimit(), frameScale);
        owner.scrollLeft = step.current();
        owner.targetScrollLeft = step.target();
        return step.moving();
    }

    private boolean stepVerticalScroll(double frameScale) {
        ScrollStep step = stepScrollAxis(owner.scrollTop, owner.targetScrollTop, getVerticalScrollLimit(), frameScale);
        owner.scrollTop = step.current();
        owner.targetScrollTop = step.target();
        return step.moving();
    }

    private ScrollStep stepScrollAxis(double current, double target, double limit, double frameScale) {
        double clampedTarget = clampScrollTarget(target, limit);
        if (target < 0 || target > limit) {
            target = easeToward(target, clampedTarget, 0.28, frameScale);
        }
        if (!isScrollSettled(current, target)) {
            current = easeToward(current, target, SCROLL_EASING_FACTOR, frameScale);
        }
        if (Math.abs(target - clampedTarget) <= SCROLL_STOP_EPSILON) {
            target = clampedTarget;
        }
        if (isScrollSettled(current, target) && isScrollSettled(target, clampedTarget)) {
            current = clampedTarget;
            target = clampedTarget;
        }
        return new ScrollStep(current, target, !isScrollSettled(current, target));
    }

    private double consumeFrameScale() {
        long now = System.nanoTime();
        if (lastRenderStepNs <= 0L) {
            lastRenderStepNs = now;
            return 1.0;
        }
        double elapsedMs = Math.max(0, Math.min(MAX_FRAME_MS, (now - lastRenderStepNs) / 1_000_000.0));
        lastRenderStepNs = now;
        return Math.max(0.25, elapsedMs / BASE_FRAME_MS);
    }

    private double easeToward(double current, double target, double factor, double frameScale) {
        if (factor <= 0) return current;
        if (factor >= 1) return target;
        double adjusted = 1.0 - Math.pow(1.0 - factor, Math.max(0.0, frameScale));
        return current + (target - current) * adjusted;
    }

    private double applyOverscroll(double value, double limit) {
        if (value < 0) return value * SCROLL_OVERSCROLL_DAMPING;
        if (value > limit) return (value - limit) * SCROLL_OVERSCROLL_DAMPING + limit;
        return value;
    }

    private double clampScrollTarget(double value, double limit) {
        if (value < 0) return 0;
        if (value > limit) return limit;
        return value;
    }

    private double getHorizontalScrollLimit() {
        return getHorizontalScrollLimitFromMetrics();
    }

    private double getHorizontalScrollLimitFromMetrics() {
        return Math.max(0, owner.scrollWidth - getScrollportWidth());
    }

    private double getVerticalScrollLimit() {
        return getVerticalScrollLimitFromMetrics();
    }

    private double getVerticalScrollLimitFromMetrics() {
        return Math.max(0, owner.scrollHeight - getScrollportHeight());
    }

    private double getScrollportWidth() {
        if (isViewportScroller()) {
            return Math.max(0, owner.document.getViewport().layoutWidth() - getVerticalScrollbarGutter());
        }
        return Box.of(owner).innerSize().width();
    }

    private double getScrollportHeight() {
        if (isViewportScroller()) {
            return Math.max(0, owner.document.getViewport().layoutHeight() - getHorizontalScrollbarGutter());
        }
        return Box.of(owner).innerSize().height();
    }

    private boolean isViewportScroller() {
        return owner.document != null
                && owner.document.documentElement != null
                && owner == owner.document.documentElement;
    }

    private String resolveViewportOverflowX() {
        return resolveViewportOverflow(true);
    }

    private String resolveViewportOverflowY() {
        return resolveViewportOverflow(false);
    }

    /** 有效 overflow：viewport 滚动器走 viewport 解析，普通元素走自身样式。 */
    private String resolveOverflowX() {
        return isViewportScroller() ? resolveViewportOverflowX() : Interaction.resolveOverflowX(owner.getComputedStyle());
    }

    private String resolveOverflowY() {
        return isViewportScroller() ? resolveViewportOverflowY() : Interaction.resolveOverflowY(owner.getComputedStyle());
    }

    /** CSS Overflow propagates body overflow to the viewport while html remains visible. */
    private String resolveViewportOverflow(boolean horizontal) {
        String rootOverflow = horizontal
                ? Interaction.resolveOverflowX(owner.getComputedStyle())
                : Interaction.resolveOverflowY(owner.getComputedStyle());
        if (!"visible".equals(rootOverflow)) return rootOverflow;

        Element body = owner.document.body;
        if (body == null) return rootOverflow;
        return horizontal
                ? Interaction.resolveOverflowX(body.getComputedStyle())
                : Interaction.resolveOverflowY(body.getComputedStyle());
    }

    private boolean allowsViewportUserScroll(String overflow) {
        String normalized = Interaction.normalizeOverflow(overflow);
        return !"hidden".equals(normalized) && !"clip".equals(normalized);
    }

    /** Commits the scroll area from used layout boxes, never from paint bounds. */
    public void commitLayoutMetrics() {
        if (!(owner instanceof AbstractText)) {
            Size contentSize = measureLayoutScrollArea();
            if (isViewportScroller() && owner.document.body != null) {
                // The viewport scrolling element's scroll area includes the body
                // box even when the layout tree does not expose it as a normal
                // child contribution of html.
                Size bodyContentSize = measureLayoutScrollArea(owner.document.body);
                contentSize = new Size(
                        Math.max(contentSize.width(), bodyContentSize.width()),
                        Math.max(contentSize.height(), bodyContentSize.height())
                );
            }
            owner.scrollWidth = contentSize.width();
            owner.scrollHeight = contentSize.height();
        }
        updateScrollbarVisibility();
    }

    private Size measureLayoutScrollArea() {
        return measureLayoutScrollArea(owner);
    }

    private static Size measureLayoutScrollArea(Element scrollport) {
        if (scrollport == null) return Size.ZERO;
        Box box = Box.of(scrollport);
        double contentOriginX = box.offset("left");
        double contentOriginY = box.offset("top");
        double width = 0;
        double height = 0;
        for (Element child : scrollport.getRenderChildren()) {
            Style style = child.getRawComputedStyle();
            if ("none".equals(style.display) || "fixed".equals(style.position)) continue;

            Position offset = Position.getOffset(child);
            Size outerSize = Box.of(child).size();
            width = Math.max(width, offset.x - contentOriginX + outerSize.width());
            height = Math.max(height, offset.y - contentOriginY + outerSize.height());
        }
        return new Size(Math.max(0, width), Math.max(0, height));
    }

    private void updateScrollbarVisibility() {
        Size rawScrollport = rawScrollportSize();
        String overflowX = resolveOverflowX();
        String overflowY = resolveOverflowY();

        boolean forceHorizontal = "scroll".equals(overflowX);
        boolean forceVertical = "scroll".equals(overflowY);
        boolean autoHorizontal = "auto".equals(overflowX) || isViewportScroller() && "visible".equals(overflowX);
        boolean autoVertical = "auto".equals(overflowY) || isViewportScroller() && "visible".equals(overflowY);

        boolean nextHorizontal = forceHorizontal;
        boolean nextVertical = forceVertical;
        double gutter = scrollbarGutter();
        for (int i = 0; i < 3; i++) {
            double availableWidth = Math.max(0, rawScrollport.width() - (nextVertical ? gutter : 0));
            double availableHeight = Math.max(0, rawScrollport.height() - (nextHorizontal ? gutter : 0));
            boolean resolvedHorizontal = forceHorizontal
                    || autoHorizontal && owner.scrollWidth > availableWidth + SCROLLBAR_EPSILON;
            boolean resolvedVertical = forceVertical
                    || autoVertical && owner.scrollHeight > availableHeight + SCROLLBAR_EPSILON;
            if (resolvedHorizontal == nextHorizontal && resolvedVertical == nextVertical) break;
            nextHorizontal = resolvedHorizontal;
            nextVertical = resolvedVertical;
        }

        setScrollbarVisibility(nextHorizontal, nextVertical);
    }

    private void setScrollbarVisibility(boolean horizontal, boolean vertical) {
        if (horizontal == horizontalScrollbarVisible && vertical == verticalScrollbarVisible) return;
        horizontalScrollbarVisible = horizontal;
        verticalScrollbarVisible = vertical;
        scrollbarLayoutDirty = true;
    }

    /**
     * 把刚提交的滚动条可见性同步到几何缓存上。
     *
     * <p>{@code scroll.commitLayoutMetrics()} 既可能从 {@code Element.tick()}（几何提交之前）
     * 调用，也可能从 {@code LayoutCommit} 的全量提交路径在提交完几何之后调用。后者如果只置
     * {@code scrollbarLayoutDirty} 而不立刻失效，gutter 这个布局输入就要等到下一个 tick 才生效：
     * 出现滚动条的那一帧内容盒仍然是旧宽度，子网格会按旧宽度算轨道并溢出容器，
     * 而视图上没有任何东西再依赖网格宽度，看起来就是"错位且不自愈"。</p>
     *
     * <p>在提交路径里就地失效是安全的：本帧的几何已经提交完，下一次绘制（或下一次 tick）
     * 会按正确的 gutter 重新布局。</p>
     */
    public void syncLayoutAfterMetricsCommit() {
        if (!scrollbarLayoutDirty) return;
        scrollbarLayoutDirty = false;
        owner.getRenderer().invalidateLayoutSubtree();
        if (owner.document != null) {
            owner.document.markDirty(owner, Drawer.RELAYOUT | Drawer.REPAINT | Drawer.HITTEST);
        }
    }

    private boolean mayShowHorizontalScrollbar() {
        String overflow = resolveOverflowX();
        return "auto".equals(overflow) || "scroll".equals(overflow)
                || isViewportScroller() && "visible".equals(overflow);
    }

    private boolean mayShowVerticalScrollbar() {
        String overflow = resolveOverflowY();
        return "auto".equals(overflow) || "scroll".equals(overflow)
                || isViewportScroller() && "visible".equals(overflow);
    }

    private Size rawScrollportSize() {
        if (isViewportScroller()) {
            return new Size(
                    Math.max(0, owner.document.getViewport().layoutWidth()),
                    Math.max(0, owner.document.getViewport().layoutHeight())
            );
        }
        return Box.of(owner).rawInnerSize();
    }

    private void drawVerticalScrollbar(PoseStack poseStack, Position bodyPos, Size bodySize) {
        AxisGeometry geometry = axisGeometry(true, bodyPos, bodySize);
        if (geometry == null) return;
        drawScrollbarTrackAndThumb(poseStack,
                (float) geometry.trackX, (float) geometry.trackY,
                (float) geometry.trackWidth, (float) geometry.trackHeight,
                (float) geometry.thumbX, (float) geometry.thumbY,
                (float) geometry.thumbWidth, (float) geometry.thumbHeight);
    }

    private void drawHorizontalScrollbar(PoseStack poseStack, Position bodyPos, Size bodySize) {
        AxisGeometry geometry = axisGeometry(false, bodyPos, bodySize);
        if (geometry == null) return;
        drawScrollbarTrackAndThumb(poseStack,
                (float) geometry.trackX, (float) geometry.trackY,
                (float) geometry.trackWidth, (float) geometry.trackHeight,
                (float) geometry.thumbX, (float) geometry.thumbY,
                (float) geometry.thumbWidth, (float) geometry.thumbHeight);
    }

    private AxisGeometry axisGeometry(boolean vertical, Rect rect) {
        if (rect == null || (vertical ? !verticalScrollbarVisible : !horizontalScrollbarVisible)) return null;
        return axisGeometry(vertical, rect.getBodyRectPosition(), rect.getBodyRectSize());
    }

    /** 按轴参数化的轨道/滑块几何：vertical=true 对应原 verticalGeometry，否则 horizontalGeometry。 */
    private AxisGeometry axisGeometry(boolean vertical, Position bodyPos, Size bodySize) {
        double scrollport = vertical ? getScrollportHeight() : getScrollportWidth();
        double trackSize = scrollbarTrackSize();
        double trackInset = scrollbarTrackInset();
        double crossGutter = vertical ? getHorizontalScrollbarGutter() : getVerticalScrollbarGutter();
        double trackExtent = Math.max(0, (vertical ? bodySize.height() : bodySize.width()) - crossGutter - trackInset * 2);
        if (trackExtent <= 0) return null;
        double scrollExtent = vertical ? owner.scrollHeight : owner.scrollWidth;
        double thumbExtent = scrollExtent <= scrollport + SCROLLBAR_EPSILON
                ? trackExtent
                : Math.max(scrollbarMinThumbLength(),
                        trackExtent * (scrollport / Math.max(scrollport, scrollExtent)));
        thumbExtent = Math.min(trackExtent, thumbExtent);
        double maxTravel = Math.max(0, trackExtent - thumbExtent);
        double scrollLimit = Math.max(0, scrollExtent - scrollport);
        double scrollPos = vertical ? getScrollTop() : getScrollLeft();
        double thumbOffset = scrollLimit <= 0 ? 0
                : Math.max(0, Math.min(scrollPos, scrollLimit)) / scrollLimit * maxTravel;

        double trackX = vertical ? bodyPos.x + bodySize.width() - trackSize - trackInset : bodyPos.x + trackInset;
        double trackY = vertical ? bodyPos.y + trackInset : bodyPos.y + bodySize.height() - trackSize - trackInset;
        double trackWidth = vertical ? trackSize : trackExtent;
        double trackHeight = vertical ? trackExtent : trackSize;
        double thumbX = vertical ? trackX : trackX + thumbOffset;
        double thumbY = vertical ? trackY + thumbOffset : trackY;
        double thumbWidth = vertical ? trackSize : thumbExtent;
        double thumbHeight = vertical ? thumbExtent : trackSize;
        double hitX = vertical ? bodyPos.x + bodySize.width() - scrollbarGutter() : bodyPos.x;
        double hitY = vertical ? bodyPos.y : bodyPos.y + bodySize.height() - scrollbarGutter();
        double hitWidth = vertical ? scrollbarGutter() : Math.max(0, bodySize.width() - getVerticalScrollbarGutter());
        double hitHeight = vertical ? Math.max(0, bodySize.height() - getHorizontalScrollbarGutter()) : scrollbarGutter();
        return new AxisGeometry(vertical, trackX, trackY, trackWidth, trackHeight,
                thumbX, thumbY, thumbWidth, thumbHeight, hitX, hitY, hitWidth, hitHeight);
    }

    private double devicePixelsToDocumentPixels(double devicePixels) {
        double scale = owner.document == null || owner.document.getViewport() == null
                ? 1.0d : owner.document.getViewport().scissorScale();
        if (!(scale > 0) || !Double.isFinite(scale)) scale = 1.0d;
        return devicePixels / scale;
    }

    private static boolean contains(AxisGeometry geometry, double x, double y) {
        return geometry != null
                && x >= geometry.hitX && x <= geometry.hitX + geometry.hitWidth
                && y >= geometry.hitY && y <= geometry.hitY + geometry.hitHeight;
    }

    private void setScrollImmediate(boolean vertical, double value) {
        double beforeLeft = owner.getTargetScrollLeft();
        double beforeTop = owner.getTargetScrollTop();
        if (vertical) {
            double clamped = clampScrollTarget(value, getVerticalScrollLimitFromMetrics());
            owner.scrollTop = clamped;
            owner.targetScrollTop = clamped;
        } else {
            double clamped = clampScrollTarget(value, getHorizontalScrollLimitFromMetrics());
            owner.scrollLeft = clamped;
            owner.targetScrollLeft = clamped;
        }
        lastRenderStepNs = 0L;
        owner.getRenderer().invalidateScrollVersion();
        if (owner.document != null) {
            owner.document.markDirty(owner, Drawer.REPAINT | Drawer.HITTEST);
        }
        owner.dispatchScrollEventIfChanged(beforeLeft, beforeTop);
    }

    private void drawScrollbarTrackAndThumb(PoseStack poseStack,
                                            float trackX, float trackY, float trackWidth, float trackHeight,
                                            float thumbX, float thumbY, float thumbWidth, float thumbHeight) {
        float trackRadius = scrollbarCornerRadius(trackWidth, trackHeight);
        float thumbRadius = scrollbarCornerRadius(thumbWidth, thumbHeight);
        int trackColor = scrollbarTrackColor();
        int thumbColor = scrollbarThumbColor();
        poseStack.pushPose();
        try {
            if ((trackColor >>> 24) != 0) {
                Graph.drawUnifiedRoundedRect(PoseMatrices.of(poseStack), trackX, trackY, trackWidth, trackHeight,
                        new float[]{trackRadius, trackRadius, trackRadius, trackRadius}, trackColor);
            }
            Base.offsetPaintDepth(poseStack, SCROLLBAR_THUMB_DEPTH_FRACTION);
            if ((thumbColor >>> 24) != 0) {
                Graph.drawUnifiedRoundedRect(PoseMatrices.of(poseStack), thumbX, thumbY, thumbWidth, thumbHeight,
                        new float[]{thumbRadius, thumbRadius, thumbRadius, thumbRadius}, thumbColor);
            }
        } finally {
            poseStack.popPose();
        }
    }

    /**
     * 圆角：优先 {@code ::-webkit-scrollbar-thumb { border-radius }} / track 的
     * border-radius；未声明时保持默认胶囊形（短边一半）。
     */
    private float scrollbarCornerRadius(float width, float height) {
        PseudoElement kind = PseudoElement.SCROLLBAR_THUMB;
        Double parsed = parseCssLength(pseudoValue(kind, "borderRadius", null));
        if (parsed == null) {
            parsed = parseCssLength(pseudoValue(PseudoElement.SCROLLBAR_TRACK, "borderRadius", null));
        }
        if (parsed != null) {
            double maxRadius = Math.min(width, height) / 2.0d;
            return (float) Math.max(0d, Math.min(parsed, maxRadius));
        }
        return Math.min(width, height) / 2f;
    }

    /**
     * 轨道颜色：{@code ::-webkit-scrollbar-track { background-color }} 优先，
     * 其次 {@code scrollbar-color} 的第二个 token，最后回退到默认值。
     */
    private int scrollbarTrackColor() {
        String declared = pseudoValue(PseudoElement.SCROLLBAR_TRACK, "backgroundColor", null);
        if (declared == null) {
            declared = com.sighs.apricityui.style.Interaction.scrollbarTrackColor(
                    owner.getComputedStyle().scrollbarColor);
        }
        return declared == null ? SCROLLBAR_DEFAULT_TRACK_COLOR : com.sighs.apricityui.parser.Color.parse(declared);
    }

    /**
     * 滑块颜色：悬停态 {@code ::-webkit-scrollbar-thumb:hover} 优先（当指针
     * 位于滑块上），其次 {@code ::-webkit-scrollbar-thumb { background-color }}，
     * 再次 {@code scrollbar-color} 的第一个 token，最后回退到默认值。
     */
    private int scrollbarThumbColor() {
        String declared = null;
        if (isThumbHovered()) {
            declared = pseudoValue(PseudoElement.SCROLLBAR_THUMB_HOVER, "backgroundColor", null);
        }
        if (declared == null) {
            declared = pseudoValue(PseudoElement.SCROLLBAR_THUMB, "backgroundColor", null);
        }
        if (declared == null) {
            declared = com.sighs.apricityui.style.Interaction.scrollbarThumbColor(
                    owner.getComputedStyle().scrollbarColor);
        }
        return declared == null ? SCROLLBAR_DEFAULT_THUMB_COLOR : com.sighs.apricityui.parser.Color.parse(declared);
    }

    /**
     * 悬停态只在状态翻转的那一帧标脏，避免每帧都触发重绘；离开滑块时同样
     * 需要一次重绘才能把颜色恢复成基础态。
     */
    private void trackThumbHoverRepaint() {
        boolean hovered = isThumbHovered();
        if (hovered == lastThumbHovered) return;
        lastThumbHovered = hovered;
        if (owner.document != null) {
            owner.document.markDirty(owner, Drawer.REPAINT);
        }
    }

    /** 指针是否落在垂直或水平滑块上（用于 :hover 变体）。 */
    public boolean isThumbHovered() {
        if (owner.document == null) return false;
        Position mouse = com.sighs.apricityui.render.Operation.getMousePosition();
        if (mouse == null) mouse = com.sighs.apricityui.render.Operation.getMousePositionDirectly();
        if (mouse == null) return false;
        Position local = owner.document.screenToDocumentPosition(mouse);
        if (local == null) return false;
        Rect rect = Rect.of(owner);
        return isPointerOnThumb(axisGeometry(true, rect), local) || isPointerOnThumb(axisGeometry(false, rect), local);
    }

    private static boolean isPointerOnThumb(AxisGeometry geometry, Position point) {
        if (geometry == null || point == null) return false;
        return point.x >= geometry.thumbX && point.x <= geometry.thumbX + geometry.thumbWidth
                && point.y >= geometry.thumbY && point.y <= geometry.thumbY + geometry.thumbHeight;
    }

    private boolean isScrollSettled(double current, double target) {
        return Math.abs(current - target) <= SCROLL_STOP_EPSILON;
    }

    private record ScrollStep(double current, double target, boolean moving) {
    }

    private enum DragAxis {
        NONE,
        VERTICAL,
        HORIZONTAL
    }

    private record AxisGeometry(boolean vertical,
                                double trackX, double trackY, double trackWidth, double trackHeight,
                                double thumbX, double thumbY, double thumbWidth, double thumbHeight,
                                double hitX, double hitY, double hitWidth, double hitHeight) {
        public double trackStart() {
            return vertical ? trackY : trackX;
        }

        public double trackLength() {
            return vertical ? trackHeight : trackWidth;
        }

        public double thumbStart() {
            return vertical ? thumbY : thumbX;
        }

        public double thumbLength() {
            return vertical ? thumbHeight : thumbWidth;
        }

        public double thumbEnd() {
            return thumbStart() + thumbLength();
        }
    }
}
